-- 2024-12-03 change model from zNewModel.bin to zblank.bin
-- 2024-12-30 add heli mixes library screenshot
-- 2025-07-22 adapt macro to new Ethos 1.7 source select
-- 2025-07-28 adapt to new '+' add button for mixes, lsw, sf, vars
-- 2025-09-09 add bottombar-heli.png and bottombar-multirotor.png

dofile("/macros/common.lua")
--simulator.setDateTime({year=2024, month=6, day=24, hour=20, min=0, sec=0, lock=true})

-- for the blank shots

simulator.loadModel("zblank.bin")
-- load user defined checklist
simulator.sleep(1) -- wait for checklist to load
simulator.screenshot("/screenshots/model-checklist-user-checklist.png")
simulator.pressKey(KEY_ENTER) --ack alert
simulator.pressKey(KEY_MDL) -- open model menu

simulator.turnRotaryEncoder(11) -- scroll to lsw
simulator.pressKey(KEY_ENTER)
simulator.screenshot("/screenshots/model-lsw-add.png")
simulator.pressKey(KEY_RTN)
simulator.turnRotaryEncoder(1) -- scroll to sf
simulator.pressKey(KEY_ENTER)
simulator.screenshot("/screenshots/model-sf-add.png")
simulator.pressKey(KEY_RTN)
simulator.turnRotaryEncoder(2) -- scroll to vars
simulator.pressKey(KEY_ENTER)
-- simulator.screenshot("/screenshots/model-icon-vars.png")
simulator.pressKey(KEY_ENTER)
simulator.screenshot("/screenshots/model-vars-add.png")
-- simulator.turnRotaryEncoder(1) -- to vars
-- simulator.pressKey(KEY_ENTER)
-- simulator.screenshot("/screenshots/model-vars-edit.png")
simulator.pressKey(KEY_RTN)
simulator.pressKey(KEY_RTN)
simulator.pressKey(KEY_RTN) -- back to model menu
--
-- open configure sreens
simulator.pressKey(KEY_DISP) -- open configure sreens
-- simulator.screenshot("/screenshots/display-home.png")
--simulator.turnRotaryEncoder(2)
--simulator.pressKey(KEY_ENTER)
--simulator.screenshot("/screenshots/display-change-source.png")
--simulator.pressKey(KEY_RTN)
simulator.turnRotaryEncoder(8) --scroll to new screen
simulator.screenshot("/screenshots/display-home.png")
simulator.pressKey(KEY_RTN, 1) -- return home
--
-- get heli library screenshot
simulator.pressKey(KEY_MDL) --open model menu
simulator.turnRotaryEncoder(1) --scroll to model select
--simulator.pressKey(KEY_ENTER)
simulator.pressKey(KEY_ENTER) --open
simulator.turnRotaryEncoder(7) --scroll to add new model
simulator.pressKey(KEY_ENTER) --y
simulator.turnRotaryEncoder(1) --scroll to create model
simulator.pressKey(KEY_ENTER) --y
simulator.turnRotaryEncoder(3) --scroll to heli
simulator.pressKey(KEY_ENTER) --y
simulator.pressKey(KEY_PAGE) --accept fbl swash
simulator.pressKey(KEY_PAGE) --accept ch reorder
--simulator.pressKey(KEY_PAGE)
--simulator.pressKey(KEY_PAGE)
simulator.turnRotaryEncoder(1) --scroll to name
simulator.pressKey(KEY_ENTER) --y
simulator.turnRotaryEncoder(1) --scroll to A
--simulator.pressKey(KEY_ENTER) --
simulator.pressKey(KEY_RTN) --exit name field
simulator.pressKey(KEY_PAGE) --page to end
simulator.screenshot("/screenshots/bottombar-heli.png", {x=0, y=410, w=800, h=70})
--simulator.pressKey(KEY_PAGE)
--simulator.pressKey(KEY_PAGE)
simulator.pressKey(KEY_MDL) --open model menu
simulator.turnRotaryEncoder(4) --scroll to mixes
simulator.pressKey(KEY_ENTER) --y
--simulator.turnRotaryEncoder(8) --scroll add mix
--simulator.pressKey(KEY_ENTER) --y
simulator.touch(546, 91) -- add new mix button '+'
simulator.screenshot("/screenshots/model-mixes-library-heli.png")
simulator.pressKey(KEY_RTN, 1)
--
-- get multirotor library screenshot
simulator.loadModel("zblank.bin")
-- load user defined checklist
simulator.sleep(1) -- wait for checklist to load
-- simulator.screenshot("/screenshots/model-checklist-user-checklist.png")
simulator.pressKey(KEY_ENTER) --ack checklist

simulator.pressKey(KEY_MDL) --open model menu
simulator.turnRotaryEncoder(1) --y
--simulator.pressKey(KEY_ENTER)
simulator.pressKey(KEY_ENTER) --open
simulator.turnRotaryEncoder(7) --scroll to add ne model
simulator.pressKey(KEY_ENTER) --y
simulator.turnRotaryEncoder(1) --scroll to create model
simulator.pressKey(KEY_ENTER) --y
simulator.turnRotaryEncoder(4) --scroll to multirotor
simulator.pressKey(KEY_ENTER) --y
simulator.pressKey(KEY_PAGE) --accept ch reorder
--simulator.pressKey(KEY_PAGE) --
--simulator.pressKey(KEY_PAGE)
--simulator.pressKey(KEY_PAGE)
simulator.turnRotaryEncoder(1) --scroll to name
simulator.pressKey(KEY_ENTER) ---
simulator.turnRotaryEncoder(1) --scroll to A
--simulator.pressKey(KEY_ENTER) --y
simulator.pressKey(KEY_RTN)
--simulator.pressKey(KEY_PAGE)
--simulator.pressKey(KEY_PAGE)
simulator.pressKey(KEY_PAGE) --page to end
simulator.screenshot("/screenshots/bottombar-multirotor.png", {x=0, y=410, w=800, h=70})
simulator.pressKey(KEY_MDL) --open model menu
simulator.turnRotaryEncoder(4) --scroll to mixes
simulator.pressKey(KEY_ENTER) --y
--simulator.turnRotaryEncoder(8) --scroll add mix
--simulator.pressKey(KEY_ENTER) --y
simulator.touch(546, 91) -- add new mix button '+'
simulator.screenshot("/screenshots/model-mixes-library-multirotor.png")
simulator.pressKey(KEY_RTN, 1)